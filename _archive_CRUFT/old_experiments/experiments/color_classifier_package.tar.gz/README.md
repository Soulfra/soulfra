# color_classifier

Binary classifier: Warm vs Cool colors (RGB)

## Architecture

- **Input:** 3 neurons
- **Hidden:** [32] neurons
- **Output:** 1 neurons
- **Trained:** 2025-12-22T08:33:43.301198

## Performance

- **Accuracy:** 100.00%
- **Loss:** 0.0240
- **Epochs:** 100

## Usage

```python
# Import the network
from publish import NeuralNetworkPublisher

publisher = NeuralNetworkPublisher()
publisher.import_network('color_classifier_package.tar.gz')

# Use it
from neural_network import load_neural_network
network = load_neural_network('color_classifier')
prediction = network.predict(your_input)
```

## Package Contents

- `network.json` - Trained weights and biases
- `metadata.json` - Package metadata
- `README.md` - This file

---

Generated with Soulfra Neural Network Publisher
