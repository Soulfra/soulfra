# Ocean Dreams Theme

calm, deep, flowing

## Installation

1. Extract this ZIP to your soulfra-simple directory
2. Run the import command:
   ```bash
   python3 -c "from brand_theme_manager import BrandThemeManager; BrandThemeManager().import_brand('ocean-dreams-theme.zip')"
   ```

3. View the brand at: http://localhost:5001/brand/ocean-dreams

## Theme Details

- **Personality**: calm, deep, flowing
- **Values**: tranquility, depth, exploration
- **Tone**: peaceful and contemplative
- **Target Audience**: mindfulness practitioners and creatives
- **Stories**: 3 chapters
- **Images**: 4 assets

## License

This theme is part of the Soulfra platform.
Fork, modify, and distribute freely.

---

Exported: 2025-12-22 08:05
